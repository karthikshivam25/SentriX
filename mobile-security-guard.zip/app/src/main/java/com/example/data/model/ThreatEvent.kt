package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "threat_events")
data class ThreatEvent(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // e.g. "APK_SCANNER", "LINK_CHECKER", "SMS_SCAM", "VPN", "PERMISSIONS", "BATTERY"
    val title: String,
    val description: String,
    val severity: String, // "SAFE", "WARNING", "CRITICAL", "INFO"
    val timestamp: Long = System.currentTimeMillis(),
    val status: String // "RESOLVED", "BLOCKED", "SECURE", "ALERT"
)
