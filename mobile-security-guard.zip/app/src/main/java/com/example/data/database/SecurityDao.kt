package com.example.data.database

import androidx.room.*
import com.example.data.model.UserAccount
import com.example.data.model.ThreatEvent
import kotlinx.coroutines.flow.Flow

@Dao
interface SecurityDao {
    // User Account actions
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserAccount(account: UserAccount)

    @Query("SELECT * FROM user_accounts WHERE email = :email LIMIT 1")
    suspend fun getUserAccount(email: String): UserAccount?

    @Query("SELECT * FROM user_accounts WHERE email = :email LIMIT 1")
    fun getUserAccountFlow(email: String): Flow<UserAccount?>

    // Threat Event actions
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertThreatEvent(event: ThreatEvent)

    @Query("SELECT * FROM threat_events ORDER BY timestamp DESC")
    fun getAllThreatEvents(): Flow<List<ThreatEvent>>

    @Query("SELECT * FROM threat_events WHERE type = :type ORDER BY timestamp DESC")
    fun getThreatEventsByType(type: String): Flow<List<ThreatEvent>>

    @Query("DELETE FROM threat_events")
    suspend fun clearAllThreatEvents()

    @Query("DELETE FROM threat_events WHERE id = :id")
    suspend fun deleteThreatEventById(id: Int)
}
