package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_accounts")
data class UserAccount(
    @PrimaryKey val email: String,
    val username: String,
    val passwordHash: String,
    val isPremium: Boolean = false,
    
    // Preferences config
    val vpnEnabled: Boolean = false,
    val micCameraAlerts: Boolean = true,
    val realTimeProtection: Boolean = true,
    val locationAlerts: Boolean = true,
    val smsDetectionEnabled: Boolean = true,
    val maliciousDownloadBlock: Boolean = true,
    val overlayProtection: Boolean = true,
    
    // Auto-scan capabilities (User-granted permission flows)
    val autoScanDownloadsPdf: Boolean = false,
    val autoScanIncomingEmails: Boolean = false,
    
    // Administrative superuser access
    val isAdmin: Boolean = false,
    val customMasterKey: String = "ADMIN_SHIELD_2026"
)
