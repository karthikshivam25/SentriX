package com.example.data.repository

import com.example.data.database.SecurityDao
import com.example.data.model.UserAccount
import com.example.data.model.ThreatEvent
import kotlinx.coroutines.flow.Flow

class SecurityRepository(private val securityDao: SecurityDao) {

    // Account methods
    suspend fun insertAccount(account: UserAccount) {
        securityDao.insertUserAccount(account)
    }

    suspend fun getAccount(email: String): UserAccount? {
        return securityDao.getUserAccount(email)
    }

    fun getAccountFlow(email: String): Flow<UserAccount?> {
        return securityDao.getUserAccountFlow(email)
    }

    // Threat methods
    suspend fun insertThreat(event: ThreatEvent) {
        securityDao.insertThreatEvent(event)
    }

    fun getAllThreats(): Flow<List<ThreatEvent>> {
        return securityDao.getAllThreatEvents()
    }

    fun getThreatsByType(type: String): Flow<List<ThreatEvent>> {
        return securityDao.getThreatEventsByType(type)
    }

    suspend fun clearThreats() {
        securityDao.clearAllThreatEvents()
    }

    suspend fun deleteThreat(id: Int) {
        securityDao.deleteThreatEventById(id)
    }
}
