package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = PrimarySec,
    secondary = SecondarySec,
    tertiary = TertiarySec,
    background = DarkBg,
    surface = DarkSurf,
    surfaceVariant = DarkSurfVariant,
    onBackground = OnDarkBg,
    onSurface = OnDarkSurf,
    onPrimary = Color(0xFF381E72),
    onSecondary = Color.White,
    onTertiary = Color.White,
    onSurfaceVariant = OnDarkBg
  )

private val LightColorScheme =
  lightColorScheme(
    primary = PrimarySec,
    secondary = SecondarySec,
    tertiary = TertiarySec,
    background = LightBg,
    surface = LightSurf,
    surfaceVariant = LightSurfVariant,
    onBackground = OnLightBg,
    onSurface = OnLightSurf,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onSurfaceVariant = OnLightBg
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
