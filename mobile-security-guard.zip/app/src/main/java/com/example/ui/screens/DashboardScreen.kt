package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.data.model.ThreatEvent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.SecurityViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: SecurityViewModel,
    onNavigateToTab: (Int) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val currentUser by viewModel.currentUser.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val scanProgress by viewModel.scanProgress.collectAsState()
    val scanName by viewModel.currentlyScanningName.collectAsState()
    val scannedApps by viewModel.scannedApps.collectAsState()
    val threats by viewModel.threatEvents.collectAsState()

    // Real battery monitors
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val batteryStatus by viewModel.batteryStatus.collectAsState()
    val batteryTemp by viewModel.batteryTemp.collectAsState()
    val batteryHealth by viewModel.batteryHealth.collectAsState()

    // Status attributes
    val activeThreatsCount = scannedApps.count { it.riskLevel == "MALICIOUS" && it.status == "ACTIVE" }
    val isVpnConnected by viewModel.vpnState.collectAsState()

    // Simple computed score (Maximum 100)
    val securityScore = remember(scannedApps, isVpnConnected.isConnected, currentUser) {
        var base = 100
        // Reduce 30 points for each unblocked active critical threat
        base -= (activeThreatsCount * 30)
        // Add or subtract points based on VPN status
        if (!isVpnConnected.isConnected) base -= 15
        // Subtract if real-time shield is turned off
        if (currentUser?.realTimeProtection == false) base -= 20
        coerceScore(base)
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "SYSTEM STATUS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFD0BCFF),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Nexus Shield",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFE6E1E5)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1C1B1F),
                    titleContentColor = Color(0xFFE6E1E5)
                ),
                actions = {
                    Badge(
                        containerColor = if (securityScore > 80) Color(0xFF10B981) else Color(0xFFEF4444),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("score_badge")
                    ) {
                        Text(
                            text = "Score: $securityScore%",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .padding(end = 16.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF49454F))
                            .border(BorderStroke(1.dp, Color(0xFF938F99)), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color(0xFFD0BCFF), CircleShape)
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Dynamic Floating Status Gauge
            item {
                Spacer(modifier = Modifier.height(8.dp))
                MainStatusCard(
                    score = securityScore,
                    isScanning = isScanning,
                    scanProgress = scanProgress,
                    scanningName = scanName,
                    triggerScan = { viewModel.triggerDeepScan() }
                )
            }

            // Section 2: Real-time Speed Booster / Ram optimization
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .clickable {
                            viewModel.performMemoryBooster { msg ->
                                Toast
                                    .makeText(context, msg, Toast.LENGTH_LONG)
                                    .show()
                            }
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF2B2930)
                    ),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0xFF49454F))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .background(Color(0xFFD0BCFF).copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.FlashOn,
                                contentDescription = "Speed Booster",
                                tint = Color(0xFFD0BCFF),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(
                                text = "Faster Hardware Execution",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Text(
                                text = "Instantly release background overhead with 1-Tap RAM Booster.",
                                fontSize = 12.sp,
                                color = Color(0xFF8E9AA8)
                            )
                        }
                        Icon(
                            imageVector = Icons.Filled.ArrowForwardIos,
                            contentDescription = "Forward",
                            tint = Color(0xFF5A6675),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Section 3: Dual-Core Diagnostics (Battery efficiency & VPN client info)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Battery telemetry Panel
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Color(0xFF49454F))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Battery Health",
                                    fontSize = 12.sp,
                                    color = Color(0xFF8E9AA8),
                                    fontWeight = FontWeight.Medium
                                )
                                Icon(
                                    imageVector = Icons.Filled.BatteryAlert,
                                    contentDescription = null,
                                    tint = Color(0xFFD0BCFF),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "$batteryLevel%",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Temp: $batteryTemp°C",
                                fontSize = 11.sp,
                                color = Color(0xFF8E9AA8)
                            )
                            Text(
                                text = "Status: $batteryStatus",
                                fontSize = 11.sp,
                                color = Color(0xFF10B981),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // VPN quick info panel
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToTab(2) }, // Goes to VPN screen
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Color(0xFF49454F))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Privacy Tunnel",
                                    fontSize = 12.sp,
                                    color = Color(0xFF8E9AA8),
                                    fontWeight = FontWeight.Medium
                                )
                                Icon(
                                    imageVector = Icons.Filled.VpnLock,
                                    contentDescription = null,
                                    tint = if (isVpnConnected.isConnected) Color(0xFF10B981) else Color(0xFF8E9AA8),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (isVpnConnected.isConnected) "ACTIVE" else "SECURE",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isVpnConnected.isConnected) Color(0xFF10B981) else Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isVpnConnected.isConnected) isVpnConnected.serverName else "Locally Protected",
                                fontSize = 11.sp,
                                color = Color(0xFF8E9AA8),
                                maxLines = 1
                            )
                            Text(
                                text = "Secured: ${String.format("%.1f", isVpnConnected.dataSecuredMb)} MB",
                                fontSize = 11.sp,
                                color = Color(0xFFD0BCFF)
                            )
                        }
                    }
                }
            }

            // Section 4: Real-Time Shield Protection Toggle Switch
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF49454F))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(
                                text = "Real-Time Mobile Protection",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Text(
                                text = "Active scans block malicious links, social engineering, and Trojans on installation.",
                                fontSize = 12.sp,
                                color = Color(0xFF8E9AA8)
                            )
                        }
                        Switch(
                            checked = currentUser?.realTimeProtection == true,
                            onCheckedChange = { viewModel.updatePreference("realTimeProtection", it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF381E72),
                                checkedTrackColor = Color(0xFFD0BCFF),
                                uncheckedThumbColor = Color(0xFF8E9AA8),
                                uncheckedTrackColor = Color(0xFF49454F)
                            )
                        )
                    }
                }
            }

            // Section 5: Header for Scan History
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Security Activity Logs",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "View Logs",
                        fontSize = 13.sp,
                        color = Color(0xFFD0BCFF),
                        modifier = Modifier.clickable { onNavigateToTab(4) } // Goes to Analytics Screen log panel
                    )
                }
            }

            // Dynamic Scan list events from Room Database!
            if (threats.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No recent threat logs logged on this device.",
                            color = Color(0xFF5A6675),
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                items(threats.take(4)) { event ->
                    ThreatReportItem(event = event)
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

// Security Gauge Circle
@Composable
fun MainStatusCard(
    score: Int,
    isScanning: Boolean,
    scanProgress: Float,
    scanningName: String,
    triggerScan: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_status_card"),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = com.example.ui.theme.DeepStatusBg
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 28.dp, horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(com.example.ui.theme.DeepStatusBg)
                    .border(
                        BorderStroke(4.dp, Color(0xFFD0BCFF)),
                        CircleShape
                    )
                    .clickable(!isScanning) { triggerScan() },
                contentAlignment = Alignment.Center
            ) {
                if (isScanning) {
                    CircularProgressIndicator(
                        progress = { scanProgress },
                        color = Color(0xFFD0BCFF),
                        trackColor = com.example.ui.theme.DeepStatusBg,
                        modifier = Modifier.size(54.dp),
                        strokeWidth = 4.dp
                    )
                } else {
                    Icon(
                        imageVector = if (score > 80) Icons.Default.Shield else Icons.Default.GppMaybe,
                        contentDescription = "Shield Guard",
                        tint = Color(0xFFD0BCFF),
                        modifier = Modifier.size(44.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            val statusText = if (isScanning) "Scanning System..." else if (score > 80) "Protected" else "Action Required"
            Text(
                text = statusText,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            val subtitleText = if (isScanning) scanningName else if (score > 80) "Last full scan: 42m ago" else "Threats detected! Clean device."
            Text(
                text = subtitleText,
                fontSize = 13.sp,
                color = Color(0xFFEADDFF).copy(alpha = 0.9f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = triggerScan,
                enabled = !isScanning,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD0BCFF),
                    contentColor = Color(0xFF381E72),
                    disabledContainerColor = Color(0xFFD0BCFF).copy(alpha = 0.5f),
                    disabledContentColor = Color(0xFF381E72).copy(alpha = 0.5f)
                ),
                shape = CircleShape,
                contentPadding = PaddingValues(horizontal = 32.dp, vertical = 12.dp)
            ) {
                Text(
                    text = if (isScanning) "SCANNING..." else "START SYSTEM SCAN",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Tap circle or button to initiate hardware audit & malware scanner",
                fontSize = 11.sp,
                color = Color(0xFFEADDFF).copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

// Log Event Item Renderer
@Composable
fun ThreatReportItem(event: ThreatEvent) {
    val severityColor = when (event.severity) {
        "SAFE" -> Color(0xFF10B981)
        "WARNING" -> Color(0xFFF59E0B)
        "CRITICAL" -> Color(0xFFEF4444)
        else -> Color(0xFF3B82F6)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF2B2930)
        ),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color(0xFF49454F))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(severityColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1.5f)) {
                Text(
                    text = event.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Text(
                    text = event.description,
                    fontSize = 12.sp,
                    color = Color(0xFF8E9AA8)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = event.status,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = severityColor,
                modifier = Modifier
                    .background(severityColor.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

private fun coerceScore(score: Int): Int {
    return score.coerceIn(5, 100)
}
