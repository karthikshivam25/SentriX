package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light / Dark color system constants representing "Professional Polish" Theme
val PrimarySec = Color(0xFFD0BCFF) // Light Deep Lavender
val SecondarySec = Color(0xFFCCC2DC) // Muted Lavender Gray
val TertiarySec = Color(0xFFEFB8C8) // Pastel Rose

// Dark mode colors under "Professional Polish" theme
val DarkBg = Color(0xFF1C1B1F) // Deep obsidian charcoal/plum
val DarkSurf = Color(0xFF2B2930) // Dark charcoal-lavender card background
val DarkSurfVariant = Color(0xFF49454F) // Border and structural line gray
val OnDarkBg = Color(0xFFE6E1E5) // Soft screen text color
val OnDarkSurf = Color(0xFFE6E1E5) // Card text color

// High intensity highlighting status background (The "Protected" status card background)
val DeepStatusBg = Color(0xFF381E72) // Pure deep royal violet container bg

// Light mode colors (fallback or matching)
val LightBg = Color(0xFFF4F6FA)
val LightSurf = Color(0xFFFFFFFF)
val LightSurfVariant = Color(0xFFE4E9F2)
val OnLightBg = Color(0xFF1A1530)
val OnLightSurf = Color(0xFF2B2930)

// Severity Colors
val ThreatSafe = Color(0xFF10B981)
val ThreatWarning = Color(0xFFF59E0B)
val ThreatCritical = Color(0xFFEF4444)
val ThreatInfo = Color(0xFF3B82F6)
