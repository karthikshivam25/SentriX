package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.SecurityViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SecurityViewModel,
    onNavigateToLogin: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    
    // Permission dialog states
    var showPermissionDialog by remember { mutableStateOf(false) }
    var permissionTitle by remember { mutableStateOf("") }
    var permissionSubtitle by remember { mutableStateOf("") }
    var permissionPrefName by remember { mutableStateOf("") }

    // Admin key entry states
    var masterKeyInput by remember { mutableStateOf("") }
    var newMasterKeyInput by remember { mutableStateOf("") }
    var keyStatusMessage by remember { mutableStateOf("") }
    var isKeyStatusSuccess by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "GUARD CONFIGURATOR",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE6E1E5),
                        letterSpacing = 1.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1C1B1F)
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Account card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    border = BorderStroke(1.dp, Color(0xFF49454F)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .background(Color(0xFFD0BCFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (currentUser?.username?.firstOrNull()?.toString() ?: "U").uppercase(),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF381E72)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = currentUser?.username ?: "Standard Guard Owner",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                if (currentUser?.isAdmin == true) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = Color(0xFFFFB4AB),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.padding(vertical = 2.dp)
                                    ) {
                                        Text(
                                            "ADMIN",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFF690005),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = currentUser?.email ?: "",
                                fontSize = 12.sp,
                                color = Color(0xFF8E9AA8)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "PREMIUM PROTECTION ACTIVE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF10B981)
                            )
                        }
                    }
                }
            }

            // Title section
            item {
                Text(
                    text = "Core Active Security Micro-Services",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            // Toggles
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // SMS Scam & UPI Scam
                    SettingsToggleRow(
                        title = "SMS Scam & UPI Fraud Analyzer",
                        subtitle = "Alert on fraudulent billing notifications, fake KYC claims",
                        checked = currentUser?.smsDetectionEnabled == true,
                        onCheckedChange = { viewModel.updatePreference("smsDetectionEnabled", it) }
                    )

                    // Overlay attacks
                    SettingsToggleRow(
                        title = "Overlay Attack Preventer",
                        subtitle = "Intercept fake screen draws overlaying official bank apps",
                        checked = currentUser?.overlayProtection == true,
                        onCheckedChange = { viewModel.updatePreference("overlayProtection", it) }
                    )

                    // Download block
                    SettingsToggleRow(
                        title = "Sandbox Download Interceptor",
                        subtitle = "Isolate unknown PDFs, APKs in secure space before sandbox boot",
                        checked = currentUser?.maliciousDownloadBlock == true,
                        onCheckedChange = { viewModel.updatePreference("maliciousDownloadBlock", it) }
                    )

                    // NEW PDF Downloads auto-scan
                    SettingsToggleRow(
                        title = "PDF Trojan & Exploit Shield",
                        subtitle = "Instantly analyze downloaded PDF files for buffer overflows & payload drops",
                        checked = currentUser?.autoScanDownloadsPdf == true,
                        onCheckedChange = { isChecked ->
                            if (isChecked) {
                                permissionTitle = "Storage & Downloads Audit Authorization"
                                permissionSubtitle = "Requesting system file monitoring permissions to dynamically intercept and scan downloaded PDF files for trojan exploits or shellcode droppers silently in the background."
                                permissionPrefName = "autoScanDownloadsPdf"
                                showPermissionDialog = true
                            } else {
                                viewModel.updatePreference("autoScanDownloadsPdf", false)
                            }
                        }
                    )

                    // NEW Incoming Email auto-scan
                    SettingsToggleRow(
                        title = "POP3/SMTP Mail Integrity Engine",
                        subtitle = "Automatically scan received email headers and body texts for hidden phishing links",
                        checked = currentUser?.autoScanIncomingEmails == true,
                        onCheckedChange = { isChecked ->
                            if (isChecked) {
                                permissionTitle = "Mail Sync & Linguistics Intercept Access"
                                permissionSubtitle = "Requesting pop/imap background telemetry read entitlements to perform real-time natural language linguistics analysis on newly received emails to flag social engineering intents immediately."
                                permissionPrefName = "autoScanIncomingEmails"
                                showPermissionDialog = true
                            } else {
                                viewModel.updatePreference("autoScanIncomingEmails", false)
                            }
                        }
                    )

                    // Location alerts
                    SettingsToggleRow(
                        title = "Contact Book & Location Alerts",
                        subtitle = "Log when secondary tools pull navigation or identity coords",
                        checked = currentUser?.locationAlerts == true,
                        onCheckedChange = { viewModel.updatePreference("locationAlerts", it) }
                    )

                    // Mic camera sensor alerts
                    SettingsToggleRow(
                        title = "Mic & Camera Active Alerts",
                        subtitle = "Notify when microphones or webcams start recording background telemetries",
                        checked = currentUser?.micCameraAlerts == true,
                        onCheckedChange = { viewModel.updatePreference("micCameraAlerts", it) }
                    )
                }
            }

            // Administrator Console Entry section
            item {
                Text(
                    text = "System Operator Entitlements",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            // Admin configuration card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    border = BorderStroke(1.dp, Color(0xFF49454F)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        if (currentUser?.isAdmin != true) {
                            // Request key to unlock
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Key, contentDescription = null, tint = Color(0xFFD0BCFF))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "Unlock Administrator Console",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Enter the administrator cryptographic masterkey to unlock live sandbox simulations and system parameter configurations.",
                                fontSize = 11.sp,
                                color = Color(0xFF8E9AA8)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            OutlinedTextField(
                                value = masterKeyInput,
                                onValueChange = { masterKeyInput = it },
                                placeholder = { Text("Enter Admin Masterkey...", fontSize = 12.sp, color = Color(0xFF8E9AA8)) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color(0xFFD0BCFF),
                                    unfocusedBorderColor = Color(0xFF49454F)
                                ),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            Button(
                                onClick = {
                                    val success = viewModel.validateAndApplyMasterKey(masterKeyInput)
                                    if (success) {
                                        keyStatusMessage = "Administrator Credentials Verified. Executive Console Unlocked."
                                        isKeyStatusSuccess = true
                                        masterKeyInput = ""
                                    } else {
                                        keyStatusMessage = "Access Denied: Invalid Masterkey Signature."
                                        isKeyStatusSuccess = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFD0BCFF),
                                    contentColor = Color(0xFF381E72)
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Submit Masterkey", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            
                            if (keyStatusMessage.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = keyStatusMessage,
                                    color = if (isKeyStatusSuccess) Color(0xFF10B981) else Color(0xFFEF4444),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Default Masterkey: ADMIN_SHIELD_2026",
                                fontSize = 10.sp,
                                color = Color(0xFF8E9AA8).copy(alpha = 0.7f),
                                fontWeight = FontWeight.Medium
                            )
                        } else {
                            // Admin Console active!
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Terminal, contentDescription = null, tint = Color(0xFF625B71))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    "ROOT ADMINISTRATOR CONSOLE",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFFFFB4AB)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                color = Color(0xFF4F378B).copy(alpha = 0.3f),
                                border = BorderStroke(1.dp, Color(0xFFD0BCFF)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(Color(0xFF10B981), CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "STATUS: ESCALATED OPERATOR MODE",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFD0BCFF)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Divider(color = Color(0xFF49454F))
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            // Edit/Configuration of dynamic custom admin masterkey itself!
                            Text(
                                "Modify Admin Masterkey Token",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                "Configure a custom administrative bypass code for subsequent network logons.",
                                fontSize = 10.sp,
                                color = Color(0xFF8E9AA8)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = newMasterKeyInput,
                                    onValueChange = { newMasterKeyInput = it },
                                    placeholder = { Text("New Custom Masterkey...", fontSize = 11.sp, color = Color(0xFF8E9AA8)) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFFD0BCFF),
                                        unfocusedBorderColor = Color(0xFF49454F)
                                    ),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                Button(
                                    onClick = {
                                        if (newMasterKeyInput.isNotBlank()) {
                                            viewModel.updateCustomMasterKey(newMasterKeyInput)
                                            keyStatusMessage = "Masterkey Updated to: $newMasterKeyInput"
                                            isKeyStatusSuccess = true
                                            newMasterKeyInput = ""
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFFFB2B1),
                                        contentColor = Color(0xFF680016)
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Apply Key", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            Divider(color = Color(0xFF49454F))
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            // Trigger Automatic scanner actions
                            Text(
                                "Background Auto-Scan Simulations",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                "Simulate raw background events to verify your auto-scanning engines and file risk detection heuristics in real-time.",
                                fontSize = 10.sp,
                                color = Color(0xFF8E9AA8)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { 
                                        viewModel.simulatePdfDownloadAndAutoScan()
                                        keyStatusMessage = "Simulated Event Sent: PDF downloaded"
                                        isKeyStatusSuccess = true
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF4F378B),
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Simulate PDF Download & AutoScan", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                
                                Button(
                                    onClick = { 
                                        viewModel.simulateIncomingEmailAndAutoScan()
                                        keyStatusMessage = "Simulated Event Sent: Incoming Email received"
                                        isKeyStatusSuccess = true
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF4F378B),
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Filled.MailOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Simulate Phishing SMTP Mail & AutoScan", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    viewModel.updatePreference("isAdmin", false)
                                    keyStatusMessage = "Demoted Administrator privileges successfully."
                                    isKeyStatusSuccess = false
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.Transparent,
                                    contentColor = Color(0xFFFFB4AB)
                                ),
                                border = BorderStroke(1.dp, Color(0xFF8E9AA8)),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Relinquish Admin Rights", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Logout card
            item {
                Button(
                    onClick = { viewModel.logOut(onNavigateToLogin) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("logout_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFEF4444).copy(alpha = 0.15f),
                        contentColor = Color(0xFFEF4444)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("LOG OUT SECURE DEVICE SESSION", fontWeight = FontWeight.Bold)
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // High fidelity custom permission popup sheet
    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Filled.Security,
                    contentDescription = null,
                    tint = Color(0xFFD0BCFF),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = permissionTitle,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            },
            text = {
                Text(
                    text = permissionSubtitle,
                    fontSize = 12.sp,
                    color = Color(0xFF8E9AA8)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updatePreference(permissionPrefName, true)
                        showPermissionDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD0BCFF),
                        contentColor = Color(0xFF381E72)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Grant Permission", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showPermissionDialog = false }
                ) {
                    Text("Deny Access", color = Color(0xFFFFB4AB), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF2B2930),
            shape = RoundedCornerShape(24.dp)
        )
    }
}

@Composable
fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
        border = BorderStroke(1.dp, Color(0xFF49454F)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.5f)) {
                Text(
                    title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Text(
                    subtitle,
                    fontSize = 11.sp,
                    color = Color(0xFF8E9AA8)
                )
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color(0xFF381E72),
                    checkedTrackColor = Color(0xFFD0BCFF),
                    uncheckedThumbColor = Color(0xFF8E9AA8),
                    uncheckedTrackColor = Color(0xFF49454F)
                )
            )
        }
    }
}
