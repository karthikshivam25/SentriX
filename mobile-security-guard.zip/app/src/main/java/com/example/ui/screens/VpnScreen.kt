package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.SecurityViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VpnScreen(viewModel: SecurityViewModel) {
    val vpnState by viewModel.vpnState.collectAsState()
    
    // Infinite scale heartbeat pulse for active connection
    val infiniteTransition = rememberInfiniteTransition(label = "Radar pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Pulse scale"
    )

    val servers = listOf(
        Pair("Secure Tunnel - Zurich", "109.202.107.4"),
        Pair("High Speed - Singapore", "128.199.112.55"),
        Pair("Privacy Exit - Tokyo", "153.125.2.22"),
        Pair("Anoymous Node - Seattle", "192.241.22.185")
    )

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "INTEGRATED SECURE VPN",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE6E1E5),
                        letterSpacing = 1.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1C1B1F)
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    border = BorderStroke(1.dp, Color(0xFF49454F)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Military-Grade DNS & Traffic Anonymization",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Encrypt banking operations, avoid overlay injection hijackers, and defend device network streams from rogue Wi-Fi snooping.",
                            fontSize = 11.sp,
                            color = Color(0xFF8E9AA8),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // Connection Main Active Button
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Radiant Ripple Indicator
                        Box(
                            modifier = Modifier
                                .size(140.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        if (vpnState.isConnected) {
                                            listOf(Color(0xFFD0BCFF).copy(alpha = 0.25f), Color.Transparent)
                                        } else {
                                            listOf(Color(0xFFEF4444).copy(alpha = 0.15f), Color.Transparent)
                                        }
                                    )
                                )
                                .scale(if (vpnState.isConnected) pulseScale else 1.0f)
                                .clickable { viewModel.toggleVpn(!vpnState.isConnected) },
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(90.dp)
                                    .background(
                                        if (vpnState.isConnected) Color(0xFF10B981) else Color(0xFFEF4444).copy(alpha = 0.15f),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (vpnState.isConnected) Icons.Filled.VpnLock else Icons.Filled.LockOpen,
                                    contentDescription = null,
                                    tint = if (vpnState.isConnected) Color(0xFF0C101B) else Color(0xFFEF4444),
                                    modifier = Modifier.size(38.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (vpnState.isConnected) "TUNNEL INSTANCE ACTIVE" else "CONNECTION EXPOSED & UNENCRYPTED",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (vpnState.isConnected) Color(0xFF10B981) else Color(0xFFEF4444)
                        )
                        Text(
                            text = if (vpnState.isConnected) "Virtual IP: ${vpnState.serverIP} • ping: ${vpnState.latencyMs} ms" else "Local DNS exposure hazard present",
                            fontSize = 12.sp,
                            color = Color(0xFF8E9AA8),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // Connected Metrics panel
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    border = BorderStroke(1.dp, Color(0xFF49454F)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Secured Bytes", fontSize = 11.sp, color = Color(0xFF8E9AA8))
                            Text("${String.format("%.1f", vpnState.dataSecuredMb)} Mb", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Protocol", fontSize = 11.sp, color = Color(0xFF8E9AA8))
                            Text(vpnState.protocol, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Tunnel Status", fontSize = 11.sp, color = Color(0xFF8E9AA8))
                            Text(if (vpnState.isConnected) "ESTABLISHED" else "IDLE", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = if (vpnState.isConnected) Color(0xFF10B981) else Color(0xFFEF4444))
                        }
                    }
                }
            }

            // Suspicious network checks
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF49454F))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.WifiTetheringError,
                            contentDescription = null,
                            tint = if (vpnState.isConnected) Color(0xFF10B981) else Color(0xFFF59E0B),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = if (vpnState.isConnected) "Rogue Wifi Defense Shields Active" else "Rogue Wifi Access Vulnerability",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = if (vpnState.isConnected) "All Wi-Fi packages securely encapsulated with CHA-CHA20 encryption." else "Enabling VPN protects credentials against MITM WiFi interceptors.",
                                fontSize = 11.sp,
                                color = Color(0xFF8E9AA8)
                            )
                        }
                    }
                }
            }

            // Server node selection
            item {
                Text(
                    text = "Select Secure Geographic Server Node",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            // Server nodes selection mapping
            items(servers.size) { index ->
                val server = servers[index]
                val isSelected = vpnState.serverName == server.first

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectVpnServer(server.first, server.second) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFFD0BCFF).copy(alpha = 0.08f) else Color(0xFF2B2930)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        1.dp,
                        if (isSelected) Color(0xFFD0BCFF) else Color(0xFF49454F)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.PinDrop,
                                contentDescription = null,
                                tint = if (isSelected) Color(0xFFD0BCFF) else Color(0xFF8E9AA8),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = server.first,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                                Text(
                                    text = "IP Interface: ${server.second}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF8E9AA8)
                                )
                            }
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Active Selection",
                                tint = Color(0xFFD0BCFF),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
