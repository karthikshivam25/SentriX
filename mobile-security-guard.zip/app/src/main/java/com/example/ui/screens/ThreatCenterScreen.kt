package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Doorbell
import androidx.compose.material.icons.outlined.LockClock
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.SecurityViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThreatCenterScreen(viewModel: SecurityViewModel) {
    var selectedThreatTab by remember { mutableStateOf(0) } // 0: APK Scan, 1: Phishing Link, 2: Permissions, 3: File Sandbox

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "THREAT MANAGEMENT CENTER",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE6E1E5),
                        letterSpacing = 1.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1C1B1F)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Horizontal Tab Controls
            TabRow(
                selectedTabIndex = selectedThreatTab,
                containerColor = Color.Transparent,
                contentColor = Color(0xFFD0BCFF),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedThreatTab]),
                        color = Color(0xFFD0BCFF)
                    )
                },
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Tab(
                    selected = selectedThreatTab == 0,
                    onClick = { selectedThreatTab = 0 },
                    text = { Text("App Sandbox", fontSize = 11.sp, maxLines = 1) }
                )
                Tab(
                    selected = selectedThreatTab == 1,
                    onClick = { selectedThreatTab = 1 },
                    text = { Text("Web Shield", fontSize = 11.sp, maxLines = 1) }
                )
                Tab(
                    selected = selectedThreatTab == 2,
                    onClick = { selectedThreatTab = 2 },
                    text = { Text("Privacy", fontSize = 11.sp, maxLines = 1) }
                )
                Tab(
                    selected = selectedThreatTab == 3,
                    onClick = { selectedThreatTab = 3 },
                    text = { Text("Files API", fontSize = 11.sp, maxLines = 1) }
                )
            }

            Box(modifier = Modifier.weight(1f)) {
                when (selectedThreatTab) {
                    0 -> AppSandboxPanel(viewModel)
                    1 -> UrlShieldPanel(viewModel)
                    2 -> PrivacyModulePanel(viewModel)
                    3 -> FileSandboxPanel(viewModel)
                }
            }
        }
    }
}

// App Sandbox Audit Panel
@Composable
fun AppSandboxPanel(viewModel: SecurityViewModel) {
    val scannedApps by viewModel.scannedApps.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
            border = BorderStroke(1.dp, Color(0xFF49454F)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "APK Security Scanner & App Reputation System",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "ShieldGuard behavioral threat analyzer monitors background installation parameters to trap trojans & malware payloads safely.",
                    fontSize = 11.sp,
                    color = Color(0xFF8E9AA8),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(scannedApps) { app ->
                val riskColor = when (app.riskLevel) {
                    "CLEAN" -> Color(0xFF10B981)
                    "SUSPICIOUS" -> Color(0xFFF59E0B)
                    else -> Color(0xFFEF4444)
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (app.status == "QUARANTINED") Color(0xFF1E2845).copy(alpha = 0.5f) else Color(0xFF2B2930)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        1.dp,
                        if (app.status == "QUARANTINED") Color(0xFF5A6675) else Color(0xFF49454F)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BaseAppIcon(app.riskLevel)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = app.name,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (app.status == "QUARANTINED") Color(0xFF8E9AA8) else Color.White
                                    )
                                    Text(
                                        text = "${app.packageName} • ${app.version}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF5A6675)
                                    )
                                }
                            }

                            Text(
                                text = if (app.status == "QUARANTINED") "QUARANTINED" else app.riskLevel,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (app.status == "QUARANTINED") Color(0xFF8E9AA8) else riskColor,
                                modifier = Modifier
                                    .background(
                                        if (app.status == "QUARANTINED") Color(0xFF5A6675).copy(alpha = 0.15f) else riskColor.copy(alpha = 0.12f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = app.description,
                            fontSize = 12.sp,
                            color = Color(0xFF8E9AA8),
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        Text(
                            text = "Granted Access API: ${app.permissionsGranted.joinToString(", ")}",
                            fontSize = 11.sp,
                            color = Color(0xFF5A6675),
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        // Action sandbox toggle
                        if (app.riskLevel != "CLEAN") {
                            Button(
                                onClick = { viewModel.toggleAppStatus(app.packageName) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (app.status == "QUARANTINED") Color(0xFF10B981) else Color(0xFFEF4444).copy(alpha = 0.2f),
                                    contentColor = if (app.status == "QUARANTINED") Color(0xFF0C101B) else Color(0xFFEF4444)
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (app.status == "QUARANTINED") "RELEASE FROM QUARANTINE" else "CONTAIN & QUARANTINE APP",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// URL Phishing & Scam Web Scanner
@Composable
fun UrlShieldPanel(viewModel: SecurityViewModel) {
    var queryUrl by remember { mutableStateOf("") }
    var scanCompleted by remember { mutableStateOf(false) }
    var scanFeedback by remember { mutableStateOf("") }
    var isThreatMatch by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
            border = BorderStroke(1.dp, Color(0xFF49454F)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Heuristic URL Website & UPI Leak Auditor",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Instantly audit links, URLs, and payment IDs for social engineering scams, credential spoof portals, or banking trojan sources.",
                    fontSize = 11.sp,
                    color = Color(0xFF8E9AA8),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        OutlinedTextField(
            value = queryUrl,
            onValueChange = { queryUrl = it },
            label = { Text("Paste Suspicious URL/Payment ID here", color = Color(0xFF8E9AA8)) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFFD0BCFF),
                unfocusedBorderColor = Color(0xFF49454F),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            shape = RoundedCornerShape(12.dp)
        )

        Button(
            onClick = {
                if (queryUrl.isNotBlank()) {
                    scanCompleted = true
                    val isScam = queryUrl.contains(".ru") || queryUrl.contains(".xyz") || queryUrl.contains("pay") || queryUrl.contains("refund")
                    isThreatMatch = isScam
                    scanFeedback = if (isScam) {
                        "⚠️ CRITICAL SPECIMEN INTRUSION\n\nVerdict: MALICIOUS SPOOF PATTERN DETECTED\n\nThis address contains telemetry markers characteristic of Payment spoof sites or fraudulent redirect portals designed to intercept core banking accounts. DO NOT input credentials."
                    } else {
                        "🛡️ SAFE SPECIMEN PATTERN PASS\n\nVerdict: VERIFIED DOMAIN ALIGNMENT\n\nHeuristic scanners matched this coordinate to safe web registry protocols. No spoof/phishing scripts detected."
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFD0BCFF),
                contentColor = Color(0xFF381E72)
            ),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("AUDIT ADDRESS NOW", fontWeight = FontWeight.Bold)
        }

        AnimatedVisibility(
            visible = scanCompleted,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (isThreatMatch) Color(0xFFEF4444).copy(alpha = 0.1f) else Color(0xFF10B981).copy(alpha = 0.1f)
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, if (isThreatMatch) Color(0xFFEF4444).copy(alpha = 0.3f) else Color(0xFF10B981).copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isThreatMatch) Icons.Filled.ReportGmailerrorred else Icons.Filled.VerifiedUser,
                            contentDescription = null,
                            tint = if (isThreatMatch) Color(0xFFEF4444) else Color(0xFF10B981),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isThreatMatch) "DANGEROUS PHISHING DOMAIN BLOCKED" else "VERIFIED DOMAIN IS SECURE",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = scanFeedback,
                        fontSize = 12.sp,
                        color = Color(0xFFE4E9F2)
                    )
                }
            }
        }
    }
}

// Background App Privacy Monitor
@Composable
fun PrivacyModulePanel(viewModel: SecurityViewModel) {
    val alerts by viewModel.sensorAlerts.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
            border = BorderStroke(1.dp, Color(0xFF49454F)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Microphone & Camera Privacy Surveillance",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Monitoring background API triggers on camera, locations, microphone, or contact books. Revoke active channels instantly to contain background spyware.",
                    fontSize = 11.sp,
                    color = Color(0xFF8E9AA8),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(alerts) { alert ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    border = BorderStroke(1.dp, Color(0xFF49454F)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = when (alert.sensorType) {
                                    "CAMERA" -> Icons.Filled.PhotoCamera
                                    "MICROPHONE" -> Icons.Filled.Mic
                                    "LOCATION" -> Icons.Filled.MyLocation
                                    else -> Icons.Filled.ContactPhone
                                },
                                contentDescription = null,
                                tint = if (alert.isBlocked) Color(0xFFEF4444) else Color(0xFFD0BCFF),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = alert.appName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Requested background ${alert.sensorType.lowercase()}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF8E9AA8)
                                )
                            }
                        }
                        
                        Button(
                            onClick = { viewModel.toggleSensorAlert(alert.id) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (alert.isBlocked) Color(0xFF10B981) else Color(0xFF381E72),
                                contentColor = if (alert.isBlocked) Color(0xFF1C1B1F) else Color(0xFFD0BCFF)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (alert.isBlocked) "RE-ALLOW" else "REVOKE ACCESS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// PDF & Downloader Risks Analyzers
@Composable
fun FileSandboxPanel(viewModel: SecurityViewModel) {
    val files by viewModel.fileItems.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
            border = BorderStroke(1.dp, Color(0xFF49454F)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "PDF & Downloaded Files Risk Sandbox",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "ShieldGuard Sandbox isolates scanned APKs or multi-media documents to capture layout vulnerabilities before launching on Android runtime.",
                    fontSize = 11.sp,
                    color = Color(0xFF8E9AA8),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(files) { file ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    border = BorderStroke(1.dp, Color(0xFF49454F)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (file.type == "PDF") Icons.Filled.PictureAsPdf else Icons.Filled.FolderZip,
                                    contentDescription = null,
                                    tint = if (file.status == "SUSPICIOUS") Color(0xFFEF4444) else Color(0xFFD0BCFF),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = file.name,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "${file.size} • format: ${file.type}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF8E9AA8)
                                    )
                                }
                            }
                            
                            Text(
                                text = file.status,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (file.status) {
                                    "CLEAN" -> Color(0xFF10B981)
                                    "SUSPICIOUS" -> Color(0xFFEF4444)
                                    else -> Color(0xFF8E9AA8)
                                },
                                modifier = Modifier
                                    .background(Color(0xFF0C101B), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        if (file.status == "UNSCANNED") {
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.scanFileItem(file.name) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF1E2845),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("AUDIT IN ISOLATED SANDBOX", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BaseAppIcon(risk: String) {
    val color = when (risk) {
        "CLEAN" -> Color(0xFF10B981)
        "SUSPICIOUS" -> Color(0xFFF59E0B)
        else -> Color(0xFFEF4444)
    }
    Box(
        modifier = Modifier
            .size(38.dp)
            .background(color.copy(alpha = 0.1f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (risk == "CLEAN") Icons.Filled.DoneOutline else Icons.Filled.Warning,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(18.dp)
        )
    }
}
