package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.database.SecurityDatabase
import com.example.data.repository.SecurityRepository
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.SecurityViewModel
import com.example.ui.viewmodel.SecurityViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        enableEdgeToEdge()

        // Setup Local Room Persistence components
        val database = SecurityDatabase.getInstance(this)
        val repository = SecurityRepository(database.securityDao)
        val viewModelFactory = SecurityViewModelFactory(repository, applicationContext)
        val viewModel = ViewModelProvider(this, viewModelFactory)[SecurityViewModel::class.java]

        setContent {
            MyApplicationTheme {
                val navController = rememberNavController()
                val currentUser by viewModel.currentUser.collectAsState()

                // Default starting page: If user is logged in, navigate straight to dashboard. Otherwise, auth page.
                val startDestination = if (currentUser != null) "dashboard" else "auth"

                NavHost(
                    navController = navController,
                    startDestination = startDestination,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color(0xFF1C1B1F), Color(0xFF2B2930))
                            )
                        )
                ) {
                    composable("auth") {
                        AuthScreen(
                            viewModel = viewModel,
                            onAuthSuccess = {
                                navController.navigate("dashboard") {
                                    popUpTo("auth") { inclusive = true }
                                }
                            }
                        )
                    }

                    composable("dashboard") {
                        MainContainerScreen(
                            viewModel = viewModel,
                            onNavigateToLogin = {
                                navController.navigate("auth") {
                                    popUpTo("dashboard") { inclusive = true }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainContainerScreen(
    viewModel: SecurityViewModel,
    onNavigateToLogin: () -> Unit
) {
    var activeTab by remember { mutableStateOf(0) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF1C1B1F),
                tonalElevation = 8.dp,
                windowInsets = WindowInsets.navigationBars,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(Icons.Filled.Shield, contentDescription = "Dashboard") },
                    label = { Text("Console", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF381E72),
                        selectedTextColor = Color(0xFFD0BCFF),
                        indicatorColor = Color(0xFFD0BCFF),
                        unselectedIconColor = Color(0xFF938F99),
                        unselectedTextColor = Color(0xFF938F99)
                    )
                )

                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(Icons.Filled.GppMaybe, contentDescription = "Threat Center") },
                    label = { Text("Threats", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF381E72),
                        selectedTextColor = Color(0xFFD0BCFF),
                        indicatorColor = Color(0xFFD0BCFF),
                        unselectedIconColor = Color(0xFF938F99),
                        unselectedTextColor = Color(0xFF938F99)
                    )
                )

                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    icon = { Icon(Icons.Filled.VpnLock, contentDescription = "VPN") },
                    label = { Text("VPN", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF381E72),
                        selectedTextColor = Color(0xFFD0BCFF),
                        indicatorColor = Color(0xFFD0BCFF),
                        unselectedIconColor = Color(0xFF938F99),
                        unselectedTextColor = Color(0xFF938F99)
                    )
                )

                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { activeTab = 3 },
                    icon = { Icon(Icons.Filled.AutoAwesome, contentDescription = "AI Specialist") },
                    label = { Text("AI Shield", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF381E72),
                        selectedTextColor = Color(0xFFD0BCFF),
                        indicatorColor = Color(0xFFD0BCFF),
                        unselectedIconColor = Color(0xFF938F99),
                        unselectedTextColor = Color(0xFF938F99)
                    )
                )

                NavigationBarItem(
                    selected = activeTab == 4,
                    onClick = { activeTab = 4 },
                    icon = { Icon(Icons.Filled.BarChart, contentDescription = "Analytics") },
                    label = { Text("Metrics", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF381E72),
                        selectedTextColor = Color(0xFFD0BCFF),
                        indicatorColor = Color(0xFFD0BCFF),
                        unselectedIconColor = Color(0xFF938F99),
                        unselectedTextColor = Color(0xFF938F99)
                    )
                )

                NavigationBarItem(
                    selected = activeTab == 5,
                    onClick = { activeTab = 5 },
                    icon = { Icon(Icons.Filled.Tune, contentDescription = "Settings") },
                    label = { Text("Settings", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF381E72),
                        selectedTextColor = Color(0xFFD0BCFF),
                        indicatorColor = Color(0xFFD0BCFF),
                        unselectedIconColor = Color(0xFF938F99),
                        unselectedTextColor = Color(0xFF938F99)
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                0 -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToTab = { tab -> activeTab = tab }
                )
                1 -> ThreatCenterScreen(viewModel = viewModel)
                2 -> VpnScreen(viewModel = viewModel)
                3 -> AiShieldScreen(viewModel = viewModel)
                4 -> AnalyticsScreen(viewModel = viewModel)
                5 -> SettingsScreen(
                    viewModel = viewModel,
                    onNavigateToLogin = onNavigateToLogin
                )
            }
        }
    }
}
